package uvg.edu.gt;

public interface FileReader {
    String readFile(String filePath);
}