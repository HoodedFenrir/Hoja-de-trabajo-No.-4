package uvg.edu.gt;
public interface ExpressionConverter {
    String toPostfix(String infixExpression);
}
